

fetch('public/data.json')
  .then(response => response.json())
  .then(data => {
    // do something with the data
    console.log(data);
  })
  .catch(error => {
    // handle the error
    console.error(error);
  });
